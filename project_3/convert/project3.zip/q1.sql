SELECT id
FROM People
WHERE givenName = 'Marie' AND familyName = 'Curie';