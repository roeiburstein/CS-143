SELECT COUNT(DISTINCT placeId) FROM Affiliations WHERE name='University of California';
