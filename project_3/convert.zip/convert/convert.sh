#!/bin/bash

python3 convert.py
