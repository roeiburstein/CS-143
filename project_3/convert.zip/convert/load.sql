SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS Places;
DROP TABLE IF EXISTS People;
DROP TABLE IF EXISTS Organizations;
DROP TABLE IF EXISTS NobelPrizes;
DROP TABLE IF EXISTS Affiliations;
DROP TABLE IF EXISTS LaureatePrizes;
DROP TABLE IF EXISTS PrizeAffiliation;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE People(id INT, 
                    givenName VARCHAR(100), 
                    familyName VARCHAR(100), 
                    gender VARCHAR(6), 
                    birthDate DATE, 
                    birthPlaceId INT,
                    PRIMARY KEY(id));

CREATE TABLE Organizations(id INT,
                    orgName VARCHAR(100),
                    dateFounded VARCHAR(100),
                    placeId INT,
                    PRIMARY KEY(id));

CREATE TABLE Places(id INT,
                    city VARCHAR(100),
                    country VARCHAR(100),
                    PRIMARY KEY(id));

CREATE TABLE NobelPrizes(id INT,
                    awardYear INT,
                    category VARCHAR(100),
                    dateAwarded DATE,
                    motivation VARCHAR(1000),
                    prizeAmount INT,
                    PRIMARY KEY(id));

CREATE TABLE LaureatePrizes(laurId INT,
                    prizeId INT,
                    sortOrder VARCHAR(1),
                    portion VARCHAR(6),
                    prizeStatus VARCHAR(11),
                    PRIMARY KEY(laurId, prizeId));

CREATE TABLE Affiliations(id INT, 
                    name VARCHAR(100), 
                    placeId INT,
                    PRIMARY KEY(id));

CREATE TABLE PrizeAffiliation(prizeId INT,
                    affilId INT,
                    PRIMARY KEY(prizeId, affilId));

ALTER TABLE People 
ADD FOREIGN KEY (birthPlaceId) 
REFERENCES Places(id) 
ON DELETE CASCADE; 

ALTER TABLE Organizations 
ADD FOREIGN KEY (placeId) 
REFERENCES Places(id) 
ON DELETE CASCADE;

ALTER TABLE LaureatePrizes 
ADD FOREIGN KEY (laurId) 
REFERENCES People(id) 
ON DELETE CASCADE; 

ALTER TABLE LaureatePrizes 
ADD FOREIGN KEY (prizeId) 
REFERENCES NobelPrizes(id) 
ON DELETE CASCADE; 

ALTER TABLE PrizeAffiliation 
ADD FOREIGN KEY (prizeId) 
REFERENCES Affiliations(id) 
ON DELETE CASCADE; 

ALTER TABLE PrizeAffiliation 
ADD FOREIGN KEY (affilId) 
REFERENCES NobelPrizes(id) 
ON DELETE CASCADE; 

ALTER TABLE Affiliations 
ADD FOREIGN KEY (placeId) 
REFERENCES Places(id) 
ON DELETE CASCADE;

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/Places.csv' 
INTO TABLE Places
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/People.csv'
INTO TABLE People
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/Organizations.csv' 
INTO TABLE Organizations
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/NobelPrizes.csv' 
INTO TABLE NobelPrizes
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/Affiliations.csv' 
INTO TABLE Affiliations
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/LaureatePrizes.csv' 
INTO TABLE LaureatePrizes
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';

LOAD DATA LOCAL INFILE '/home/cs143/shared/project_3/convert/PrizeAffiliation.csv' 
INTO TABLE PrizeAffiliation
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
ESCAPED BY ''
LINES TERMINATED BY '\n';
