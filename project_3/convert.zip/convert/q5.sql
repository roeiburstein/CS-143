SELECT COUNT(DISTINCT NobelPrizes.awardYear) FROM NobelPrizes, LaureatePrizes, Organizations
WHERE LaureatePrizes.prizeId = NobelPrizes.id AND LaureatePrizes.laurId = Organizations.id;
