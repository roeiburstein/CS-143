select dob from Actor where id = 65793;
