load data local infile '/home/cs143/data/movie.del' into table Movie fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/actor1.del' into table Actor fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/actor2.del' into table Actor fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/actor3.del' into table Actor fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/director.del' into table Director fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/moviegenre.del' into table MovieGenre fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/moviedirector.del' into table MovieDirector fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/movieactor1.del' into table MovieActor fields terminated by ',' optionally enclosed by '"';
load data local infile '/home/cs143/data/movieactor2.del' into table MovieActor fields terminated by ',' optionally enclosed by '"';

